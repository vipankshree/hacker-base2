package com.test.client;

public class MultiClient {

	/**
	 * @param args
	 */
	public static final int NO_OF_THREADS = 50;
	
	public static void main(String[] args) {
		
	}

}
